<?php 

?>
<div class="heroSection">heroSection</div>