<?php
global $haamin;
// slider widgets

$options = get_option('haamin');


$gallery = [];

if (isset($options['site_gallery'])) {
    $gallery_raw = $options['site_gallery'];

    // بررسی کن که آیا به صورت json ذخیره شده یا آرایه است
    if (is_string($gallery_raw)) {
        $maybe_json = json_decode($gallery_raw, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($maybe_json)) {
            $gallery = $maybe_json;
        }
    } elseif (is_array($gallery_raw)) {
        $gallery = $gallery_raw;
    }
}



?>
<div class="swiper slider-one">
    <!-- Additional required wrapper -->
    <?php if (!empty($gallery)): ?>
        <div class="swiper-wrapper">
            <?php foreach ($gallery as $image): ?>
                <div class="swiper-slide">
                    <img src="<?php echo esc_url($image['url']); ?>" alt="">
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- If we need pagination -->
    <div class="swiper-pagination"></div>

    <!-- If we need navigation buttons -->
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>

    <!-- If we need scrollbar -->
    <div class="swiper-scrollbar"></div>
</div>