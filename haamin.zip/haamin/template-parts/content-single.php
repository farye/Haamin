<?php 

?>
<!-- content signle -->
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
  <header class="entry-header">
    <h1><?php the_title(); ?></h1>
    <div class="meta"><?php echo get_the_date(); ?> | <?php the_author(); ?></div>
  </header>
  <div class="entry-content">
    <?php the_content(); ?>
  </div>
</article>
