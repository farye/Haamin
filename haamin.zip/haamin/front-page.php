<?php get_header(); ?>
<main class="homepage">
    <h2>صفحه اصلی</h2>
    <?php
    require get_template_directory() . '/widgets/heroSection.php';
    require get_template_directory() . '/widgets/slider.php';
    ?>

</main>
<?php get_footer(); ?>