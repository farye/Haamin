<?php

// Redux_Metaboxes::set_box(
// 	$opt_name,
// 	array(
// 		'id' => 'project-metaboxes',
// 		'title' => esc_html__('Project Options', 'tg-text-domain'),
// 		'post_types' => array('projects'),
// 		'position' => 'normal', // normal, advanced, side.
// 		'priority' => 'high', // high, core, default, low.
// 		'sections' => array(
// 			array(
// 				'title' => esc_html__('Gallery Setting', 'tg-text-domain'),
// 				'id' => 'project-gallery-meta',
// 				'icon' => 'el-icon-cogs',
// 				'fields' => array(
// 					array(
// 						'id' => 'project-multi-media',
// 						'type' => 'multi_media',
// 						'title' => esc_html__('Project Multi Media Selector', 'tg-text-domain'),
// 						'subtitle' => esc_html__('Alternative media field which allows for multi selections', 'tg-text-domain'),
// 						'desc' => esc_html__('max_file_limit has been set to 10.', 'tg-text-domain'),
// 						'max_file_upload' => 10,
// 					)
// 				),
// 			),

// 			array(
// 				'title' => esc_html__('Project Setting', 'tg-text-domain'),
// 				'id' => 'project-setting-meta',
// 				'icon' => 'el-icon-cogs',
// 				'fields' => array(
// 					array(
// 						'id'          => 'project_details_country',
// 						'type'        => 'text',
// 						'title'    => esc_html__('تیم اجرایی ', 'tg-text-domain'),
// 					),
					
// 					array(
// 						'id'          => 'project_details_karfarma',
// 						'type'        => 'text',
// 						'title'    => esc_html__('مکان  ', 'tg-text-domain'),
// 					),

// 					array(
// 						'id'          => 'project_details_counts_days',
// 						'type'        => 'text',
// 						'title'    => esc_html__(' قیمت :', 'tg-text-domain'),
// 					),



// 					array(
// 						'id'          => 'projects_start_time',
// 						'type'        => 'text',
// 						'title'    => esc_html__('مدیر اجرایی : ', 'tg-text-domain'),
// 					),

// 					array(
// 						'id'          => 'project_details_Time_end',
// 						'type'        => 'text',
// 						'title'    => esc_html__('طراح داخلی :', 'tg-text-domain'),
// 					),


// 					array(
// 						'id'          => 'project_details_Voloum',
// 						'type'        => 'text',
// 						'title'    => esc_html__('طراح سازه :', 'tg-text-domain'),
// 						'placeholder' => esc_html__('Insert Your Market Volume', 'tg-text-domain'),
// 					),
					
// 					array(
// 						'id'          => 'project_details_designer_saze',
// 						'type'        => 'text',
// 						'title'    => esc_html__('تیم عمران :', 'tg-text-domain'),
// 					),
					
// 					array(
// 						'id'          => 'project_details_team_omran',
// 						'type'        => 'text',
// 						'title'    => esc_html__('نوع همکاری :', 'tg-text-domain'),
// 					),
				
// 				),
// 			)

// 		),
// 	)
// );
