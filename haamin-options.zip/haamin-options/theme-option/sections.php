<?php
Redux::set_section($opt_name, array(
    'title' => 'تنظیمات عمومی',
    'id' => 'general_settings',
    'desc' => 'این بخش تنظیمات عمومی قالب را شامل می‌شود.',
    'fields' => array(
        array(
            'id' => 'site_logo',
            'type' => 'media',
            'title' => 'لوگو سایت',
        ),
        array(
            'id' => 'site_color',
            'type' => 'color',
            'title' => 'رنگ اصلی سایت',
            'default' => '#ff0000',
        ),
           array(
            'id' => 'site_color_2',
            'type' => 'color',
            'title' => 'رنگ اصلی سایت',
            'default' => '#ff0000',
        ),
         array(
            'id' => 'site_color_3',
            'type' => 'color',
            'title' => 'رنگ اصلی سایت',
            'default' => '#ff0000',
        ),
           array(
            'id' => 'site_color_4',
            'type' => 'color',
            'title' => 'رنگ اصلی سایت',
            'default' => '#ff0000',
        ),
    )
));

// home page 
Redux::set_section($opt_name, array(
    'title' => 'تنظیمات صفحه اصلی',
    'id' => 'home_settings',
    
    'desc' => 'این بخش تنظیمات صفحه اصلی قالب را شامل می‌شود.',
    'fields' => array(
        array(
            'id'       => 'site_gallery',
            'type'     => 'gallery',
            'title'    => 'گالری تصاویر سایت',
            'subtitle' => 'چند تصویر را برای گالری انتخاب کنید.',
            'desc'     => 'می‌توانید چند تصویر انتخاب و ذخیره کنید.',
        ),

     
    )
));
