<?php

if (!class_exists('Redux')) {
    return;
}

$opt_name = "haamin";

Redux::set_args($opt_name, array(
    'opt_name' => $opt_name,
    'display_name' => 'تنظیمات قالب من',
    'menu_title' => 'تنظیمات قالب',
    'menu_type' => 'menu',
    'allow_sub_menu' => true,
    'dev_mode' => false,
));

