<?php
/*
Plugin Name: Haamin Plugin
Plugin URI: https://haamin.co
Description: haamin plugin
Version: 1.0
Author: Farbod
Author URI: 
License: perfusional
*/

defined('ABSPATH') or die('No script kiddies please!');

// کد اصلی افزونه شما از اینجا شروع می‌شود

add_action('admin_notices', function () {
    echo '<div class="notice notice-success is-dismissible"><p>افزونه ساده فعال شد!</p></div>';
});
require_once 'ht-theme-options.php';

// require_once plugin_dir_path(__FILE__) . 'theme-option/framework.php';
// require_once plugin_dir_path(__FILE__) . '';

require_once plugin_dir_path(__FILE__) . 'theme-option/config.php';
require_once plugin_dir_path(__FILE__) . 'theme-option/sections.php';
