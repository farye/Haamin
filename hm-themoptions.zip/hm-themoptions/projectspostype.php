<?php

class Tejarat_Home_Core
{
    public function __construct()
    {
        add_action('init', array($this, 'register_custom_post_type'));
        add_action('init', array($this, 'register_custom_taxonomy'));
        add_action('init', array($this, 'register_custom_tags'));
    }

    public function register_custom_post_type()
    {
        $labels = array(
            'name' => _x('Projects', 'Post Type General Name', 'tg-text-domain'),
            'singular_name' => _x('Project', 'Post Type Singular Name', 'tg-text-domain'),
            'menu_name' => __('Projects', 'tg-text-domain'),
            'name_admin_bar' => __('Project', 'tg-text-domain'),
            'archives' => __('Project Archives', 'tg-text-domain'),
            'attributes' => __('Project Attributes', 'tg-text-domain'),
            'parent_item_colon' => __('Parent Project:', 'tg-text-domain'),
            'all_items' => __('All Projects', 'tg-text-domain'),
            'add_new_item' => __('Add New Project', 'tg-text-domain'),
            'add_new' => __('Add New', 'tg-text-domain'),
            'new_item' => __('New Project', 'tg-text-domain'),
            'edit_item' => __('Edit Project', 'tg-text-domain'),
            'update_item' => __('Update Project', 'tg-text-domain'),
            'view_item' => __('View Project', 'tg-text-domain'),
            'view_items' => __('View Projects', 'tg-text-domain'),
            'search_items' => __('Search Project', 'tg-text-domain'),
            'not_found' => __('Not found', 'tg-text-domain'),
            'not_found_in_trash' => __('Not found in Trash', 'tg-text-domain'),
            'featured_image' => __('Featured Image', 'tg-text-domain'),
            'set_featured_image' => __('Set featured image', 'tg-text-domain'),
            'remove_featured_image' => __('Remove featured image', 'tg-text-domain'),
            'use_featured_image' => __('Use as featured image', 'tg-text-domain'),
            'insert_into_item' => __('Insert into item', 'tg-text-domain'),
            'uploaded_to_this_item' => __('Uploaded to this item', 'tg-text-domain'),
            'items_list' => __('Items list', 'tg-text-domain'),
            'items_list_navigation' => __('Items list navigation', 'tg-text-domain'),
            'filter_items_list' => __('Filter items list', 'tg-text-domain'),
        );

        $args = array(
            'label' => __('Projects', 'tg-text-domain'),
            'description' => __('Projects Description', 'tg-text-domain'),
            'labels' => $labels,
            'supports' => array('title', 'editor', 'thumbnail', 'custom-fields', 'comments'),
            'taxonomies' => array('project-category', 'project-tag'),
            'hierarchical' => false,
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-portfolio',
            'show_in_admin_bar' => true,
            'show_in_nav_menus' => true,
            'can_export' => true,
            'has_archive' => true,
            'exclude_from_search' => false,
            'publicly_queryable' => true,
            'capability_type' => 'page',
        );

        register_post_type('projects', $args);
    }

    public function register_custom_taxonomy()
    {
        $labels = array(
            'name' => _x('Project Categories', 'Taxonomy General Name', 'tg-text-domain'),
            'singular_name' => _x('Project Category', 'Taxonomy Singular Name', 'tg-text-domain'),
            'menu_name' => __('Project Categories', 'tg-text-domain'),
            'all_items' => __('All Project Categories', 'tg-text-domain'),
            'parent_item' => __('Parent Project Category', 'tg-text-domain'),
            'parent_item_colon' => __('Parent Project Category:', 'tg-text-domain'),
            'new_item_name' => __('New Project Category Name', 'tg-text-domain'),
            'add_new_item' => __('Add New Project Category', 'tg-text-domain'),
            'edit_item' => __('Edit Project Category', 'tg-text-domain'),
            'update_item' => __('Update Project Category', 'tg-text-domain'),
            'view_item' => __('View Project Category', 'tg-text-domain'),
            'separate_items_with_commas' => __('Separate project categories with commas', 'tg-text-domain'),
            'add_or_remove_items' => __('Add or remove project categories', 'tg-text-domain'),
            'choose_from_most_used' => __('Choose from the most used project categories', 'tg-text-domain'),
            'popular_items' => __('Popular Project Categories', 'tg-text-domain'),
            'search_items' => __('Search Project Categories', 'tg-text-domain'),
            'not_found' => __('Not Found', 'tg-text-domain'),
            'no_terms' => __('No project categories', 'tg-text-domain'),
            'items_list' => __('Project categories list', 'tg-text-domain'),
            'items_list_navigation' => __('Project categories list navigation', 'tg-text-domain'),
        );

        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
            'public' => true,
            'show_ui' => true,
            'show_admin_column' => true,
            'show_in_nav_menus' => true,
            'show_tagcloud' => true,
        );

        register_taxonomy('project-category', array('projects'), $args);
    }

    public function register_custom_tags()
    {
        $labels = array(
            'name' => _x('Project Tags', 'taxonomy general name', 'tg-text-domain'),
            'singular_name' => _x('Project Tag', 'taxonomy singular name', 'tg-text-domain'),
            'search_items' => __('Search Project Tags', 'tg-text-domain'),
            'popular_items' => __('Popular Project Tags', 'tg-text-domain'),
            'all_items' => __('All Project Tags', 'tg-text-domain'),
            'edit_item' => __('Edit Project Tag', 'tg-text-domain'),
            'update_item' => __('Update Project Tag', 'tg-text-domain'),
            'add_new_item' => __('Add New Project Tag', 'tg-text-domain'),
            'new_item_name' => __('New Project Tag Name', 'tg-text-domain'),
            'separate_items_with_commas' => __('Separate tags with commas', 'tg-text-domain'),
            'add_or_remove_items' => __('Add or remove tags', 'tg-text-domain'),
            'choose_from_most_used' => __('Choose from the most used tags', 'tg-text-domain'),
            'not_found' => __('No tags found.', 'tg-text-domain'),
            'menu_name' => __('Project Tags', 'tg-text-domain'),
        );

        $args = array(
            'hierarchical' => false,
            'labels' => $labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'update_count_callback' => '_update_post_term_count',
            'query_var' => true,
            'show_in_nav_menus' => true,
            'show_tagcloud' => true,
            'rewrite' => array('slug' => 'project-tag'),
        );

        register_taxonomy('project-tag', 'projects', $args);
    }
}

add_action('add_meta_boxes', 'tg_add_project_price_meta_box');
add_action('save_post', 'tg_save_project_price_meta');

function tg_add_project_price_meta_box() {
    add_meta_box(
        'project_price_meta_box',
        __('Project Price', 'tg-text-domain'),
        'tg_render_project_price_meta_box',
        'projects',
        'side',
        'default'
    );
}

function tg_render_project_price_meta_box($post) {
    // مقدار فعلی متا را بخوانیم
    $value = get_post_meta($post->ID, 'project_price', true);
    ?>
    <label for="project_price"><?php _e('Enter project price:', 'tg-text-domain'); ?></label>
    <input type="number" name="project_price" id="project_price" value="<?php echo esc_attr($value); ?>" style="width:100%;" />
    <?php
}

function tg_save_project_price_meta($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;

    if (isset($_POST['project_price'])) {
        update_post_meta($post_id, 'project_price', sanitize_text_field($_POST['project_price']));
    }
}

new Tejarat_Home_Core();
