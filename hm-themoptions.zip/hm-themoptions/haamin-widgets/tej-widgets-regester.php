<?php if (!defined('ABSPATH')) {
    exit;
}
class Register_Tejarat_Widget
{
   

    public function __construct()
    {
        add_action('elementor/elements/categories_registered', [$this, 'add_elementor_widget_categories']);
        add_action('elementor/widgets/register', [$this, 'register_tejarat_widget']);
        add_action('wp_enqueue_scripts', [$this, 'register_widget_scripts']);
        add_action('wp_enqueue_scripts', [$this, 'register_widget_styles']);
    }
    public function register_tejarat_widget($widgets_manager)
    {

        require_once(__DIR__ . '/widgets/dam_project.php');
        require_once(__DIR__ . '/widgets/ourTeam.php');
        require_once(__DIR__ . '/widgets/sakhtName.php      ');

        $widgets_manager->register(new \dam_project_Widget());
        $widgets_manager->register(new \SakhtName());
        $widgets_manager->register(new \OurTeam());
    }
    public function add_elementor_widget_categories($elements_manager)
    {
        $elements_manager->add_category('haamin', ['title' => esc_html__('حامین', 'tg-text-domain'), 'icon' => 'eicon-folder-o',]);
    }
    public function get_products_by_category_id($category_id)
    {
        $args = array('product_category_id' => array($category_id), 'posts_per_page' => 12, 'posts_per_page' => 12,);
        $query = new WC_Product_Query($args);
        $products = $query->get_products();
        return $products;
    }
    public function ht_reading_time($post_id)
    {
        $post = get_post($post_id);
        $content = $post->post_content;
        $content = strip_tags($content);
        $content = html_entity_decode($content, ENT_QUOTES, 'UTF-8');
        preg_match_all('/\p{L}+/u', $content, $matches);
        $word_count = count($matches[0]);
        $minutes = floor($word_count / 200);
        if ($minutes == 0) {
            return '1 ' . esc_html__('minute', 'tg-text-domain');
        } else {
            return $minutes . esc_html__('minute', 'tg-text-domain');
        }
    }
    public function product_percentage($regular, $sele)
    {
        $regular_price = (float) $regular;
        $sale_price = (float) $sele;
        if ($regular_price <= 0 || $sale_price <= 0) {
            return 0;
        }
        $discount_percentage = (($regular_price - $sale_price) / $regular_price) * 100;
        return round($discount_percentage, 2);
    }
    public function get_cat_img($category_id)
    {
        $category = get_term($category_id, 'product_cat');
        if ($category && !is_wp_error($category)) {
            $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
            if ($thumbnail_id) {
                $image_url = wp_get_attachment_url($thumbnail_id);
                if ($image_url) {
                    return $image_url;
                } else {
                    return ' ';
                }
            }
        }
    }
    public function get_cat_name_select()
    {
        $args = array('taxonomy' => 'product_cat', 'hide_empty' => true,);
        $product_categories = get_terms($args);
        $category_options = [];
        if (!is_wp_error($product_categories) && !empty($product_categories)) {
            foreach ($product_categories as $category) {
                $category_options[$category->term_id] = $category->name;
            }
        }
        return $category_options;
    }
    public function post_type_query($post_type_name, $Post_numbers, $Post_order, $Post_get)
    {
        $args = array('post_type' => $post_type_name, 'post_status' => 'publish', 'posts_per_page' => $Post_numbers, 'order' => $Post_order, 'orderby' => $Post_get);
        return new WP_Query($args);
    }
    // Method to enqueue scripts
    public function register_widget_scripts()
    {
        wp_enqueue_script('script-swiper', plugins_url('/widgets/assets/swiper/swiper-widget-script.js', __FILE__), [], '1.0.0', true);

        if (!is_front_page()) return;

        wp_enqueue_script('script-handle', plugins_url('/widgets/assets/main-widget.js', __FILE__), ['script-swiper'], '1.0.0', true);
    }

    public function register_widget_styles()
    {
        wp_enqueue_style('tailwind-style', plugins_url('widgets/assets/swiper/swiper-widget-style.css', __FILE__), [], '1.0.0');
        wp_enqueue_style('widget-swiper', plugins_url('/widgets/assets/swiper/swiper-widget-style.css', __FILE__), [], '1.0.0');

        if (!is_front_page()) return;

        wp_enqueue_style('widget-style', plugins_url('/widgets/assets/widget-style.css', __FILE__), [], '1.0.0');
    }
}
$register_tejarat_widget = new Register_Tejarat_Widget();

//cart
add_action('wp_ajax_update_cart_quantity', 'update_cart_quantity');
add_action('wp_ajax_nopriv_update_cart_quantity', 'update_cart_quantity');

function update_cart_quantity()
{
    $cart_item_key = sanitize_text_field($_POST['cart_item_key']);
    $quantity = intval($_POST['quantity']);

    if (!WC()->cart->set_quantity($cart_item_key, $quantity, true)) {
        wp_send_json_error(['message' => 'Failed to update cart.']);
    }

    ob_start();
    $widget = new Your_Cart_Widget_Class();
    echo $widget->get_cart_hover_content();
    $html = ob_get_clean();

    wp_send_json_success(['html' => $html]);
}
