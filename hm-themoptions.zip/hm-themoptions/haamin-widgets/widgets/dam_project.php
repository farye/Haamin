<?php

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography as Scheme_Typography;


class Dam_Project_Widget  extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'dam_project_Widget';
    }
    public function get_title()
    {
        return 'dam_project_Widget';
    }
    // public function get_script_depends()
    // {
    //     return ['swiper'];
    // }
    protected function register_controls()
    {
        $this->start_controls_section('content', ['label' => 'Content']);
        $repeater = new \Elementor\Repeater();
        $repeater->add_control('title1', ['type' => Controls_Manager::TEXT, 'label' => 'شماره پروژه']);
        $repeater->add_control('title2', ['type' => Controls_Manager::TEXT, 'label' => 'نام پروژه']);
        $repeater->add_control('title3', ['type' => Controls_Manager::TEXT, 'label' => 'Title 3']);
        $repeater->add_control('title4', ['type' => Controls_Manager::TEXT, 'label' => 'سال ساخت']);
        $repeater->add_control('description', ['type' => Controls_Manager::TEXTAREA, 'label' => 'Description']);
        $repeater->add_control('image1', ['type' => Controls_Manager::MEDIA, 'label' => 'Iعکس پروژه']);
        $repeater->add_control('image2', ['type' => Controls_Manager::MEDIA, 'label' => 'عکس ارچیتکت']);
        $repeater->add_control('image3', ['type' => Controls_Manager::MEDIA, 'label' => 'عکس نقشه']);
        $repeater->add_control('link1', ['type' => Controls_Manager::URL, 'label' => 'لینک پروژه']);
        $repeater->add_control('link2', ['type' => Controls_Manager::URL, 'label' => 'لینک لوکیشن']);

        $this->add_control('slides', [
            'type' => Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'title_field' => '{title1}',
        ]);
        $this->end_controls_section();
    }

    protected function render()
    {
        $slides = $this->get_settings_for_display('slides');
        if (empty($slides)) return;
?>
<!-- <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/> -->
        <main class="swiper-container my-slider">
            <div class="swiper-wrapper">
                <?php foreach ($slides as $item): ?>
                    <article itemscope itemtype="https://schema.org/CreativeWork" class="swiper-slide slide-content-project" style="background-image: url('<?php echo esc_url($item['image1']['url']); ?>');">

                        <div class="contents-projects">
                            <div class="svg-back">
                                <svg xmlns="http://www.w3.org/2000/svg" width="1400" height="900" viewBox="0 0 1400 900" fill="none">
                                    <path d="M453 751H800V752H453V900H452V680H0V679H452V223H0V222H452V0H453V751Z" fill="#D9D9D9" />
                                    <path d="M949 150H1400V151H949V561H1400V562H949V900H948V151H600V150H948V0H949V150Z" fill="#D9D9D9" />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M1396 887.122H1391.22V890.536H1395.32V895.317H1390.54V891.22H1387.12V896H1340V894.634H1385.76V891.22H1348.2V890.536H1385.76V885.756H1390.54V848.195H1391.22V885.756H1394.63V840H1396V887.122ZM1391.22 894.634H1394.63V891.22H1391.22V894.634ZM1387.12 890.536H1390.54V887.122H1387.12V890.536Z" fill="#D9D9D9" />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M1008 566.366H962.244V569.78H999.805V570.464H962.244V575.244H957.464V612.805H956.78V575.244H953.366V621H952V573.878H956.78V570.464H952.683V565.683H957.464V569.78H960.878V565H1008V566.366ZM957.464 573.878H960.878V570.464H957.464V573.878ZM953.366 569.78H956.78V566.366H953.366V569.78Z" fill="#D9D9D9" />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M448 209.122H443.22V212.536H447.317V217.317H442.536V213.22H439.122V218H392V216.634H437.756V213.22H400.195V212.536H437.756V207.756H442.536V170.195H443.22V207.756H446.634V162H448V209.122ZM443.22 216.634H446.634V213.22H443.22V216.634ZM439.122 212.536H442.536V209.122H439.122V212.536Z" fill="#D9D9D9" />
                                    <path fill-rule="evenodd" clip-rule="evenodd" d="M60 5.36621H14.2441V8.78027H51.8047V9.46387H14.2441V14.2441H9.46387V51.8047H8.78027V14.2441H5.36621V60H4V12.8779H8.78027V9.46387H4.68262V4.68262H9.46387V8.78027H12.8779V4H60V5.36621ZM9.46387 12.8779H12.8779V9.46387H9.46387V12.8779ZM5.36621 8.78027H8.78027V5.36621H5.36621V8.78027Z" fill="#D9D9D9" />
                                </svg>
                            </div>
                            <!-- ستون 1: عنوان، تصویر، نام پروژه -->
                            <div class="column-1 bg-gray-100">
                                <div class="title-widgets read-mehrshad" >
                                    <div class="icon-title-widgets" aria-hidden="true">
                                        <!-- آیکون تزئینی SVG -->
                                        <svg xmlns="http://www.w3.org/2000/svg" width="43" height="66" viewBox="0 0 43 66" fill="none">
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M27.007 4.08042V27.8991L29.4406 27.256V5.79657H42.3649V36.7536L27.007 40.8122V66H24.7578V41.4067L17.6163 43.2939V66H15.3671V43.8883L12.9243 44.534V65.9956H0V35.0364L15.3581 30.9776V4.08063L21.1813 0L27.007 4.08042ZM31.6898 28.9732L2.24927 36.7536V63.7618H10.675V42.8168L40.1156 35.0364V8.03038H31.6898V28.9732ZM22.271 26.8396L20.0211 27.4342L20.0538 3.52349L17.6073 5.23833V30.3831L24.7578 28.4935V5.23855L22.3031 3.51913L22.271 26.8396Z" fill="#F9F9F9" />
                                            <path d="M22.306 66H20.0567V44.9616L22.306 44.3671V66Z" fill="#F9F9F9" />
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M42.3649 65.9954H29.4406V42.6056L42.3649 38.9977V65.9954ZM31.6898 44.298V63.7616H40.1156V41.9459L31.6898 44.298Z" fill="#F9F9F9" />
                                            <path fill-rule="evenodd" clip-rule="evenodd" d="M12.9243 29.369L0 32.6062V5.79657H12.9243V29.369ZM2.24927 29.7389L10.675 27.6286V8.03038H2.24927V29.7389Z" fill="#F9F9F9" />
                                        </svg>

                                    </div>

                                    <!-- تیتر اصلی اسلاید -->
                                    <h2 itemprop="headline" class="name-title-widgets">پروژه‌ها</h2>
                                    <span class="after-title-widgets">نیم‌نگاه</span>
                                </div>

                                <!-- تصویر معماری پروژه -->
                                <div class="img-architect read-mehrshad">
                                    <img src="<?= esc_url($item['image2']['url']) ?>"
                                        alt="نمای معماری از پروژه <?= esc_attr($item['title2']) ?>"
                                        loading="lazy"
                                        itemprop="image">
                                </div>

                                <!-- نام پروژه -->
                                <div itemprop="name" class="project-name read-mehrshad">
                                    <sapn class="number-project-name"><?= esc_html($item['title1']) ?></sapn>
                                    <h3 class="under-number-project-name">پروژه‌ی</h3>

                                    <h3 class="title-project-name">
                                        <a href="<?= esc_url($item['link1']['url']) ?>"
                                            itemprop="url"
                                            title="اطلاعات بیشتر درباره پروژه <?= esc_attr($item['title2']) ?>">
                                            <?= esc_html($item['title2']) ?>
                                        </a>
                                    </h3>
                                </div>

                            </div>

                            <!-- ستون 2: طراح، تصویر پروژه -->
                            <div class="column-2">
                                <div class="designer read-mehrshad">
                                    <span class="desigh-by">طراحی شده توسط</span>
                                    <h3 itemprop="creator" class="creator"><?= esc_html($item['title3']) ?></h3>
                                </div>

                                <div class="img-project read-mehrshad">
                                    <img src="<?= esc_url($item['image1']['url']) ?>"
                                        alt="تصویر پروژه <?= esc_attr($item['title2']) ?>"
                                        loading="lazy"
                                        itemprop="image">
                                </div>

                                <!-- ناوبری اسلایدر -->
                                <div class="btn-slider read-mehrshad">
                                    <div class="project-button-prev" aria-label="اسلاید قبلی">

                                        <svg xmlns="http://www.w3.org/2000/svg" width="8" height="14" viewBox="0 0 8 14" fill="none">
                                            <path d="M0.000366211 12.7485L1.21366 14L7.99996 7.00002L1.21366 0L0.000366211 1.25152L5.57332 7.00002L0.000366211 12.7485Z" fill="#F9F9F9" />
                                        </svg>
                                        قبلی
                                    </div>

                                    <div class="project-button-next" aria-label="اسلاید بعدی">
                                        بعدی
                                        <svg xmlns="http://www.w3.org/2000/svg" width="8" height="14" viewBox="0 0 8 14" fill="none">
                                            <path d="M7.9996 12.7485L6.78631 14L5.24521e-06 7.00002L6.78631 0L7.9996 1.25152L2.42665 7.00002L7.9996 12.7485Z" fill="#F9F9F9" />
                                        </svg>

                                    </div>

                                </div>
                            </div>

                            <!-- ستون 3: سال ساخت، توضیح، نقشه -->
                            <div class="column-3">
                                <div class="year-make-projects read-mehrshad">
                                    <span class="name-year-make-projects">سال ساخت</span>
                                    <h3 itemprop="dateCreated" class="dateCreated"><?= esc_html($item['title4']) ?></h3>
                                </div>

                                <div class="description read-mehrshad">
                                    <p itemprop="description" class="desc-description"><?= esc_html($item['description']) ?></p>
                                </div>

                                <div class="img-map read-mehrshad">
                                    <a href="<?= esc_url($item['link2']['url']) ?>"
                                        title="مشاهده موقعیت پروژه <?= esc_attr($item['title2']) ?>"
                                        itemprop="url">
                                        <img src="<?= esc_url($item['image3']['url']) ?>"
                                            alt="نقشه موقعیت پروژه <?= esc_attr($item['title2']) ?>"
                                            loading="lazy">
                                    </a>
                                </div>
                            </div>
                        </div>


                    </article>
                <?php endforeach; ?>
            </div>
        </main>
<!-- <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script> -->

<?php
    }
}
