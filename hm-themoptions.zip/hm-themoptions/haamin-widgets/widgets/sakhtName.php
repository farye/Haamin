<?php
class SakhtName extends \Elementor\Widget_Base
{
    public function get_name()
    {
        return 'sakht_name';
    }

    public function get_title()
    {
        return 'ساخت نامه';
    }

    public function get_icon()
    {
        return 'eicon-tabs';
    }

    public function get_categories()
    {
        return ['haamin'];
    }

    protected function register_controls()
    {
        $this->start_controls_section('tabs_section', [
            'label' => 'تب‌ها',
        ]);

        $slide_repeater = new \Elementor\Repeater();


        $slide_repeater->add_control('slide_image', [
            'label' => 'تصویر',
            'type' => \Elementor\Controls_Manager::MEDIA,
        ]);
        $slide_repeater->add_control('slide_title', [
            'label' => 'تیتر',
            'type' => \Elementor\Controls_Manager::TEXT,
        ]);

        $slide_repeater->add_control('slide_description', [
            'label' => 'توضیحات',
            'type' => \Elementor\Controls_Manager::TEXTAREA,
        ]);
        $slide_repeater->add_control('slide_date', [
            'label' => 'تاریخ',
            'type' => \Elementor\Controls_Manager::TEXT,
        ]);
        $slide_repeater->add_control('slide_views', [
            'label' => 'تعداد بازدید',
            'type' => \Elementor\Controls_Manager::NUMBER,
        ]);

        $tab_repeater = new \Elementor\Repeater();
        $tab_repeater->add_control('tab_title', [
            'label' => 'عنوان تب',
            'type' => \Elementor\Controls_Manager::TEXT,
        ]);

        $tab_repeater->add_control('tab_subtext', [
            'label' => 'توضیح زیر عنوان تب',
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => '',
        ]);

        $tab_repeater->add_control('tab_slides', [
            'label' => 'اسلایدها',
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $slide_repeater->get_controls(),
        ]);

        $this->add_control('tabs', [
            'label' => 'لیست تب‌ها',
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $tab_repeater->get_controls(),
        ]);

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
?>
        <section class="tab-slider-widget" aria-label="ویجت تب با اسلایدر">
            <nav class="tabs" role="tablist">
                <?php foreach ($settings['tabs'] as $index => $tab): ?>
                    <div class="tab-header">
                        <div id="tab-btn-<?php echo $index; ?>" class="tab-button <?php echo $index === 0 ? 'active' : ''; ?>" data-tab="tab<?php echo $index; ?>" role="tab" aria-controls="tab<?php echo $index; ?>" aria-selected="<?php echo $index === 0 ? 'true' : 'false'; ?>">
                            <?php echo esc_html($tab['tab_title']); ?>
                            <?php if (!empty($tab['tab_subtext'])): ?>
                                <div class="tab-subtext"><?php echo esc_html($tab['tab_subtext']); ?></div>
                            <?php endif; ?>
                        </div>

                    </div>
                <?php endforeach; ?>

            </nav>
            <div class="tab-content">
                <?php foreach ($settings['tabs'] as $index => $tab): ?>
                    <article class="tab-pane <?php echo $index === 0 ? 'active' : ''; ?>" id="tab<?php echo $index; ?>" role="tabpanel" aria-labelledby="tab-btn-<?php echo $index; ?>">
                        <div class="swiper swiper-tabs swiper<?php echo $index; ?>">
                            <div class="swiper-wrapper">
                                <?php foreach ($tab['tab_slides'] as $slide): ?>
                                    <div class="swiper-slide slide-tabs">
                                        <figure>
                                            <img src="<?php echo esc_url($slide['slide_image']['url']); ?>" alt="<?php echo esc_attr($slide['slide_title']); ?>" loading="lazy">
                                            <figcaption class="slide-content">
                                                <h2><?php echo esc_html($slide['slide_title']); ?></h2>
                                                <p><?php echo esc_html($slide['slide_description']); ?></p>
                                                <footer class="meta">
                                                    <time datetime="<?php echo esc_attr($slide['slide_date']); ?>">
                                                        <?php echo esc_html($slide['slide_date']); ?>
                                                    </time>
                                                    <span class="views" aria-label="بازدید">👁 <?php echo esc_html($slide['slide_views']); ?></span>
                                                </footer>
                                            </figcaption>
                                        </figure>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="swiper-button-prev" aria-label="قبلی"></div>
                            <div class="swiper-button-next" aria-label="بعدی"></div>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>

        <script>
            function initTabSliderWidget() {
                document.querySelectorAll('.tab-button').forEach(button => {
                    button.addEventListener('click', () => {
                        const tabId = button.dataset.tab;

                        // دکمه‌های تب
                        document.querySelectorAll('.tab-button').forEach(btn => {
                            btn.classList.remove('active');
                            btn.setAttribute('aria-selected', 'false');
                        });
                        button.classList.add('active');
                        button.setAttribute('aria-selected', 'true');

                        // تب‌ها
                        document.querySelectorAll('.tab-pane').forEach(pane => {
                            pane.classList.remove('active');
                            pane.style.display = 'none';
                        });
                        const selectedPane = document.getElementById(tabId);
                        if (selectedPane) {
                            selectedPane.classList.add('active');
                            selectedPane.style.display = 'block';

                            // Re-initialize Swiper inside shown tab
                            const swiperContainer = selectedPane.querySelector('.swiper');
                            if (swiperContainer && !swiperContainer.classList.contains('swiper-initialized')) {
                                new Swiper(swiperContainer, {
                                    loop: false,
                                    slidesPerView: 3,
                                    initialSlide: 1,

                                    centeredSlides: true,
                                    spaceBetween: 30,
                                    navigation: {
                                        nextEl: selectedPane.querySelector('.swiper-button-next'),
                                        prevEl: selectedPane.querySelector('.swiper-button-prev'),
                                    },
                                });
                            }
                        }
                    });
                });

                // Initialize only the first tab's Swiper
                const firstSwiper = document.querySelector('.tab-pane.active .swiper');
                if (firstSwiper) {
                    new Swiper(firstSwiper, {
                        loop: false,
                        slidesPerView: 3,
                        initialSlide: 1,

                        centeredSlides: true,
                        spaceBetween: 24,
                        navigation: {
                            nextEl: firstSwiper.querySelector('.swiper-button-next'),
                            prevEl: firstSwiper.querySelector('.swiper-button-prev'),
                        },
                    });
                }
            }

            // Elementor hook to run script in editor and live
            jQuery(window).on('elementor/frontend/init', function() {
                elementorFrontend.hooks.addAction('frontend/element_ready/global', function() {
                    initTabSliderWidget();
                });
            });
        </script>
        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.css"> -->
        <!-- <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script> -->
<?php
    }
}
