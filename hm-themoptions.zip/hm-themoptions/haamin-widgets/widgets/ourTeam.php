<?php

use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Typography as Scheme_Typography;

class OurTeam extends \Elementor\Widget_Base
{
  public function get_name()
  {
    return 'team_swiper';
  }
  public function get_title()
  {
    return 'خانواده‌ی حامین';
  }
  public function get_script_depends()
  {
    return ['swiper'];
  }
  protected function register_controls()
  {
    $this->start_controls_section('content', ['label' => 'Content']);
    $repeater = new \Elementor\Repeater();

    $repeater->add_control('ability', ['type' => Controls_Manager::TEXT, 'label' => 'سمت ']);
    $repeater->add_control('name_person', ['type' => Controls_Manager::TEXT, 'label' => 'نام ']);
    $repeater->add_control('fr_img', ['type' => Controls_Manager::MEDIA, 'label' => 'عکس اول']);
    $repeater->add_control('hv_img', ['type' => Controls_Manager::MEDIA, 'label' => 'عکس هاور']);
    $repeater->add_control('link1', ['type' => Controls_Manager::URL, 'label' => 'لینک صفحه شخصی']);

    $this->add_control('slides_team', [
      'type' => Controls_Manager::REPEATER,
      'fields' => $repeater->get_controls(),
      'title_field' => '{ability  }',
    ]);
    $this->end_controls_section();
  }

  protected function render()
  {
    $slides_team = $this->get_settings_for_display('slides_team');
    if (empty($slides_team)) return;
?>
    <div class="swiper-container team-slider" role="region" aria-label="Team Members Slider">
      <div class="swiper-wrapper">
        <?php foreach ($slides_team as $item): ?>
          <div class="swiper-slide">
            <div class="main-slide-team">
              <div class="img-slide">
                <!-- تصویر اصلی -->
                <div class="fr-img">
                  <img src="<?= esc_url($item['fr_img']['url']) ?>" alt="Profile picture of <?= esc_attr($item['name_person']) ?>" />
                </div>
                <!-- تصویر هاور -->
                <div class="hv-img">
                  <img src="<?= esc_url($item['hv_img']['url']) ?>" alt="Hover image of <?= esc_attr($item['name_person']) ?>" />
                </div>
              </div>

              <!-- لینک به صفحه شخصی -->
              <a href="<?= esc_url($item['link1']['url']) ?>" class="main-ablitiy" title="View profile of <?= esc_attr($item['name_person']) ?>">
                <div class="ablitiy">
                  <h3><?= esc_html($item['ability']) ?></h3>
                </div>

                <div class="liner-team"></div>

                <!-- نام شخص -->
                <div class="name-person-abitlyty">
                  <h2><?= esc_html($item['name_person']) ?></h2>
                </div>
              </a>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

   
    </div>
   <!-- دکمه‌های ناوبری اسلایدر -->
      <div class="team-button-prev" aria-label="Previous Slide">
        <svg xmlns="http://www.w3.org/2000/svg" width="8" height="14" viewBox="0 0 8 14" fill="none">
          <g clip-path="url(#clip0_743_1193)">
            <path d="M0 12.7485L1.2133 14L7.9996 7.00002L1.2133 0L0 1.25152L5.57296 7.00002L0 12.7485Z" fill="#A9B5B5" />
          </g>
          <defs>
            <clipPath id="clip0_743_1193">
              <rect width="8" height="14" fill="white" />
            </clipPath>
          </defs>
        </svg>
      </div>
          
      <div class="team-button-next" aria-label="Next Slide">
        <svg xmlns="http://www.w3.org/2000/svg" width="8" height="14" viewBox="0 0 8 14" fill="none">
          <g clip-path="url(#clip0_743_1161)">
            <path d="M8 12.7485L6.7867 14L0.000401974 7.00002L6.7867 0L8 1.25152L2.42704 7.00002L8 12.7485Z" fill="#0E3232" />
          </g>
          <defs>
            <clipPath id="clip0_743_1161">
              <rect width="8" height="14" fill="white" transform="matrix(-1 0 0 1 8 0)" />
            </clipPath>
          </defs>
        </svg>
      </div>



<?php
  }
}
