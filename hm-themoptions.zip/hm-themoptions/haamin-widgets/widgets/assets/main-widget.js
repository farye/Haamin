document.addEventListener('DOMContentLoaded', function () {
    // اسلایدر اول: my-slider
    var swiper1 = new Swiper('.my-slider', {
        navigation: {
            nextEl: '.project-button-next',
            prevEl: '.project-button-prev',
        },
        autoplay: {
            delay: 1000, 
            disableOnInteraction: false, 
        },
        speed: 700, 

        effect: 'fade',
        fadeEffect: {
            crossFade: true, 
        },
        slidesPerView: 1,  
        loop: true,
    });

    // اسلایدر دوم: team-slider
    var swiper2 = new Swiper('.team-slider', {
        navigation: {
            nextEl: '.team-button-next', 
            prevEl: '.team-button-prev', 
        },
        direction: 'horizontal',  
        slidesPerView: 3,        
        loop: true,               
        spaceBetween: 20,       
        slidesPerGroup: 1,       
        freeMode: true,          
        autoplay: {
            delay: 1000, 
            disableOnInteraction: false,
        },
        speed: 700, 
        scrollbar: {
            el: '.swiper-scrollbar', 
            draggable: true,       
        },
        breakpoints: {
            768: {
                slidesPerView: 3,  
            },
            480: {
                slidesPerView: 1,  
            }
        }
    });

});
// sakht name
