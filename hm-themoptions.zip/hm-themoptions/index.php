<?php

/*
Plugin Name: haamin core
Text Domain: tg-text-domain
Domain Path: /languages

Description: Plugin to add Post types and theme options.
Version: 1.0
Author: fabod 
*/

require_once 'haamin-widgets/tej-widgets-regester.php';
require_once 'projectspostype.php';

